import java.util.Arrays;

public class DSA18Q4 {
	public static int maximumGap(int[] arr) {
        Arrays.sort(arr);
        int l=arr.length;
        if(l<2)
        return 0;
        int max=0;
        for(int i=0;i<l-1;i++)
        {
            int c=arr[i+1]-arr[i];
            if(c>max)
            max=c;
          
        }
        return max;
       
    }
	public static void main(String[] args) {
		int[] nums = {3,6,9,1};
		int diff= maximumGap(nums);
		System.out.println(diff);
	}

}
